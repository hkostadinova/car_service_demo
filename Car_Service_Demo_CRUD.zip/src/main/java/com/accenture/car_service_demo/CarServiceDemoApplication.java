package com.accenture.car_service_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarServiceDemoApplication {

	public static void main(String[] args) {

		SpringApplication.run(CarServiceDemoApplication.class, args);
	}

}
