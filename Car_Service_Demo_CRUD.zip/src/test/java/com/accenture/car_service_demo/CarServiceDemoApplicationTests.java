package com.accenture.car_service_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarServiceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
